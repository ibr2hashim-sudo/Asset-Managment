package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.model.Asset
import com.example.data.model.AssetWithDetails
import com.example.data.model.Department
import com.example.data.model.TransferRecord
import com.example.data.model.TransferWithDetails
import com.example.data.repository.AssetRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class AssetViewModel(application: Application) : AndroidViewModel(application) {
    private val database = AppDatabase.getDatabase(application)
    private val repository = AssetRepository(
        database.assetDao(),
        database.departmentDao(),
        database.transferDao()
    )

    // Raw streams from Repository
    val departments: StateFlow<List<Department>> = repository.allDepartments
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val assetsWithDetails: StateFlow<List<AssetWithDetails>> = repository.assetsWithDetails
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val transfersWithDetails: StateFlow<List<TransferWithDetails>> = repository.transfersWithDetails
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Filtering options
    private val _searchQuery = MutableStateFlow("")
    val searchQuery = _searchQuery.asStateFlow()

    private val _selectedTypeFilter = MutableStateFlow("ALL") // "ALL", "FIXED", "MOVABLE"
    val selectedTypeFilter = _selectedTypeFilter.asStateFlow()

    private val _selectedDepartmentFilter = MutableStateFlow<Int?>(null)
    val selectedDepartmentFilter = _selectedDepartmentFilter.asStateFlow()

    // Combined filtered assets flow
    val filteredAssets: StateFlow<List<AssetWithDetails>> = combine(
        assetsWithDetails,
        _searchQuery,
        _selectedTypeFilter,
        _selectedDepartmentFilter
    ) { assets, query, type, deptId ->
        assets.filter { item ->
            val matchesQuery = query.isBlank() ||
                item.asset.name.contains(query, ignoreCase = true) ||
                item.asset.serialNumber.contains(query, ignoreCase = true) ||
                item.asset.category.contains(query, ignoreCase = true)

            val matchesType = type == "ALL" || item.asset.type == type
            val matchesDept = deptId == null || item.asset.currentDepartmentId == deptId

            matchesQuery && matchesType && matchesDept
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        // Seed default departments if database is empty
        viewModelScope.launch {
            try {
                val depts = repository.allDepartments.first()
                if (depts.isEmpty()) {
                    val itId = repository.insertDepartment(Department(name = "تقنية المعلومات", code = "IT", description = "إدارة أجهزة الحاسوب والشبكات والدعم التقني"))
                    val hrId = repository.insertDepartment(Department(name = "الموارد البشرية", code = "HR", description = "شؤون الموظفين والتوظيف والتدريب"))
                    val finId = repository.insertDepartment(Department(name = "الإدارة المالية", code = "FIN", description = "المحاسبة والميزانيات والمعاملات والدفع"))
                    val whId = repository.insertDepartment(Department(name = "المستودع الرئيسي", code = "WH", description = "المركز الرئيسي لتخزين وتوزيع الأصول"))
                    val opsId = repository.insertDepartment(Department(name = "العمليات اللوجستية", code = "LOG", description = "إدارة أسطول النقل والمعدات الميدانية"))

                    // Seed some initial assets to demonstrate the application immediately
                    repository.insertAsset(
                        Asset(
                            name = "خادم رئيسي Dell PowerEdge",
                            serialNumber = "SRV-MX928-11",
                            type = "FIXED",
                            category = "أجهزة شبكات",
                            description = "خادم قاعدة البيانات الرئيسي مجهز بذاكرة 128 جيجابايت وسعة تخزين سحابية محلية.",
                            cost = 45000.0,
                            purchaseDate = System.currentTimeMillis() - 31536000000L, // 1 year ago
                            currentDepartmentId = itId.toInt(),
                            status = "ACTIVE",
                            condition = "EXCELLENT",
                            model = "PowerEdge R750",
                            quantity = 2,
                            imageUri = null,
                            assetCode = "AST-SRV-01"
                        )
                    )

                    repository.insertAsset(
                        Asset(
                            name = "حاسوب محمول MacBook Pro 16",
                            serialNumber = "MAC-PRO-0098",
                            type = "MOVABLE",
                            category = "أجهزة حاسب",
                            description = "جهاز محمول مخصص لمطوري النظم ومصممي الواجهات بالشركة.",
                            cost = 12000.0,
                            purchaseDate = System.currentTimeMillis() - 15768000000L, // 6 months ago
                            currentDepartmentId = itId.toInt(),
                            status = "ACTIVE",
                            condition = "NEW",
                            model = "MacBook Pro M3 Max",
                            quantity = 5,
                            imageUri = null,
                            assetCode = "AST-LAP-02"
                        )
                    )

                    repository.insertAsset(
                        Asset(
                            name = "طاولة اجتماعات خشبية فاخرة",
                            serialNumber = "FURN-TB-104",
                            type = "FIXED",
                            category = "أثاث مكتب",
                            description = "طاولة اجتماعات دائرية تتسع لـ 12 شخصاً بقاعة الاجتماعات الكبرى.",
                            cost = 8500.0,
                            purchaseDate = System.currentTimeMillis() - 94608000000L, // 3 years ago
                            currentDepartmentId = hrId.toInt(),
                            status = "ACTIVE",
                            condition = "GOOD",
                            model = "Premium Oak Table",
                            quantity = 1,
                            imageUri = null,
                            assetCode = "AST-FUR-03"
                        )
                    )

                    repository.insertAsset(
                        Asset(
                            name = "شاشة عرض ذكية 75 بوصة Sony",
                            serialNumber = "TV-SONY-75A",
                            type = "MOVABLE",
                            category = "أجهزة إلكترونية",
                            description = "شاشة قاعة العروض والتدريب، مجهزة للاتصال اللاسلكي السريع.",
                            cost = 6200.0,
                            purchaseDate = System.currentTimeMillis() - 7884000000L, // 3 months ago
                            currentDepartmentId = whId.toInt(),
                            status = "ACTIVE",
                            condition = "EXCELLENT",
                            model = "Bravia XR 75",
                            quantity = 3,
                            imageUri = null,
                            assetCode = "AST-DIS-04"
                        )
                    )
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    // Filter adjustments
    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun updateTypeFilter(type: String) {
        _selectedTypeFilter.value = type
    }

    fun updateDepartmentFilter(deptId: Int?) {
        _selectedDepartmentFilter.value = deptId
    }

    // Actions
    fun addAsset(
        name: String,
        serialNumber: String,
        type: String,
        category: String,
        description: String,
        cost: Double,
        currentDepartmentId: Int,
        condition: String,
        model: String = "",
        quantity: Int = 1,
        imageUri: String? = null,
        assetCode: String = ""
    ) {
        viewModelScope.launch {
            val asset = Asset(
                name = name,
                serialNumber = serialNumber,
                type = type,
                category = category,
                description = description,
                cost = cost,
                purchaseDate = System.currentTimeMillis(),
                currentDepartmentId = currentDepartmentId,
                status = "ACTIVE",
                condition = condition,
                model = model,
                quantity = quantity,
                imageUri = imageUri,
                assetCode = assetCode
            )
            repository.insertAsset(asset)
        }
    }

    // Excel-compatible CSV Importer
    fun importAssetsFromCsv(csvText: String, onComplete: (Int, String) -> Unit) {
        viewModelScope.launch {
            try {
                val lines = csvText.lines()
                if (lines.isEmpty() || lines.first().isBlank()) {
                    onComplete(0, "الملف فارغ أو غير صالح")
                    return@launch
                }
                
                // Get header and columns
                val header = lines.first().split(",").map { it.trim().removeSurrounding("\"") }
                
                var importedCount = 0
                val departmentsList = repository.allDepartments.first()
                val defaultDept = departmentsList.firstOrNull()
                val defaultDeptId = defaultDept?.id ?: 1
                
                for (i in 1 until lines.size) {
                    val line = lines[i].trim()
                    if (line.isBlank()) continue
                    
                    // CSV column values
                    val tokens = line.split(",").map { it.trim().removeSurrounding("\"") }
                    if (tokens.isEmpty()) continue
                    
                    // Map indices dynamically based on header
                    fun getValueForHeader(arabicName: String, englishName: String): String {
                        val index = header.indexOfFirst { 
                            it.equals(arabicName, ignoreCase = true) || it.equals(englishName, ignoreCase = true) 
                        }
                        return if (index != -1 && index < tokens.size) tokens[index] else ""
                    }
                    
                    val nameValue = getValueForHeader("الاسم", "name")
                    if (nameValue.isBlank()) continue
                    
                    val serial = getValueForHeader("الرقم التسلسلي", "serialNumber").ifBlank { "SN-${System.currentTimeMillis() % 10000}-$importedCount" }
                    val type = getValueForHeader("النوع", "type").ifBlank { "MOVABLE" }
                    val category = getValueForHeader("التصنيف", "category").ifBlank { "عام" }
                    val description = getValueForHeader("الوصف", "description").ifBlank { "تم استيراده من ملف" }
                    val cost = getValueForHeader("التكلفة", "cost").toDoubleOrNull() ?: 0.0
                    val condition = getValueForHeader("الجودة", "condition").ifBlank { "NEW" }
                    val model = getValueForHeader("الموديل", "model")
                    val quantity = getValueForHeader("الكمية", "quantity").toIntOrNull() ?: 1
                    val assetCode = getValueForHeader("كود تعريفي", "assetCode").ifBlank { "AST-${System.currentTimeMillis() % 10000}-$importedCount" }
                    
                    // Check if department exists by name, otherwise use default
                    val deptName = getValueForHeader("القسم", "department")
                    var deptId = defaultDeptId
                    if (deptName.isNotBlank()) {
                        val found = departmentsList.find { it.name.equals(deptName, ignoreCase = true) || it.code.equals(deptName, ignoreCase = true) }
                        if (found != null) {
                            deptId = found.id
                        } else {
                            // Create department dynamically
                            val newDeptId = repository.insertDepartment(
                                Department(name = deptName, code = deptName.take(3).uppercase(), description = "تم إنشاؤه تلقائياً")
                            )
                            deptId = newDeptId.toInt()
                        }
                    }
                    
                    val asset = Asset(
                        name = nameValue,
                        serialNumber = serial,
                        type = type,
                        category = category,
                        description = description,
                        cost = cost,
                        purchaseDate = System.currentTimeMillis(),
                        currentDepartmentId = deptId,
                        status = "ACTIVE",
                        condition = condition,
                        model = model,
                        quantity = quantity,
                        imageUri = null,
                        assetCode = assetCode
                    )
                    repository.insertAsset(asset)
                    importedCount++
                }
                onComplete(importedCount, "تم استيراد $importedCount من الأصول بنجاح!")
            } catch (e: Exception) {
                onComplete(0, "خطأ في قراءة ملف CSV: ${e.localizedMessage}")
            }
        }
    }

    // Excel-compatible CSV Exporter
    fun exportAssetsToCsv(): String {
        val builder = StringBuilder()
        // CSV Header
        builder.append("الاسم,كود تعريفي,الموديل,الرقم التسلسلي,النوع,التصنيف,الوصف,التكلفة,الكمية,الجودة,القسم\n")
        
        val assets = filteredAssets.value
        val depts = departments.value.associateBy { it.id }
        for (item in assets) {
            val name = item.asset.name.replace(",", " ")
            val code = item.asset.assetCode.replace(",", " ")
            val model = item.asset.model.replace(",", " ")
            val serial = item.asset.serialNumber.replace(",", " ")
            val type = item.asset.type
            val category = item.asset.category.replace(",", " ")
            val description = item.asset.description.replace(",", " ")
            val cost = item.asset.cost
            val quantity = item.asset.quantity
            val condition = item.asset.condition
            val deptName = depts[item.asset.currentDepartmentId]?.name ?: "غير محدد"
            builder.append("\"$name\",\"$code\",\"$model\",\"$serial\",\"$type\",\"$category\",\"$description\",$cost,$quantity,\"$condition\",\"$deptName\"\n")
        }
        return builder.toString()
    }

    // CSV Empty Template for Excel
    fun getCsvTemplate(): String {
        val builder = StringBuilder()
        builder.append("الاسم,كود تعريفي,الموديل,الرقم التسلسلي,النوع,التصنيف,الوصف,التكلفة,الكمية,الجودة,القسم\n")
        builder.append("\"طاولة مكتبية ذكية\",\"AST-1001\",\"IKEA-Desk-X\",\"SN-99238\",\"MOVABLE\",\"أثاث مكتب\",\"طاولة مكتبية قابلة لتعديل الارتفاع\",1250,5,\"NEW\",\"الموارد البشرية\"\n")
        builder.append("\"شاشة حاسوب 27 بوصة\",\"AST-1002\",\"LG-27UL\",\"SN-88231\",\"MOVABLE\",\"أجهزة إلكترونية\",\"شاشة عرض بدقة 4K فائقة الوضوح\",1500,10,\"EXCELLENT\",\"تقنية المعلومات\"\n")
        return builder.toString()
    }

    fun updateAsset(asset: Asset) {
        viewModelScope.launch {
            repository.updateAsset(asset)
        }
    }

    fun deleteAsset(asset: Asset) {
        viewModelScope.launch {
            repository.deleteAsset(asset)
        }
    }

    fun addDepartment(name: String, code: String, description: String) {
        viewModelScope.launch {
            repository.insertDepartment(
                Department(
                    name = name,
                    code = code,
                    description = description
                )
            )
        }
    }

    fun deleteDepartment(department: Department) {
        viewModelScope.launch {
            repository.deleteDepartment(department)
        }
    }

    fun transferAsset(
        assetId: Int,
        fromDeptId: Int,
        toDeptId: Int,
        authorizedBy: String,
        notes: String,
        onComplete: (Boolean) -> Unit = {}
    ) {
        viewModelScope.launch {
            val success = repository.transferAsset(
                assetId = assetId,
                fromDeptId = fromDeptId,
                toDeptId = toDeptId,
                authorizedBy = authorizedBy,
                notes = notes
            )
            onComplete(success)
        }
    }
}
